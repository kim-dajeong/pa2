var indexSectionsWithContent =
{
  0: "bcdilmrt",
  1: "dl",
  2: "cdmrt",
  3: "i",
  4: "bl"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros",
  4: "Pages"
};

